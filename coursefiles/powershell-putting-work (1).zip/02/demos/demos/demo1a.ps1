# live demo

# Navigating previous commands arrow keys

Get-History
#has an alias of h
h

#history count
$MaximumHistoryCount

#Invoke-History
get-alias -Definition Invoke-History

r 10

Clear-Host